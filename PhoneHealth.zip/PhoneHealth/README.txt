Phone Health - Android Studio project
1) Android Studio -> Open -> यह फोल्डर चुनें -> Gradle Sync (इंटरनेट चाहिए)
2) फोन में USB debugging चालू करके Run ▶  या  Build > Build APK(s)
3) ऐप खुलने पर "सभी अनुमति दें" दबाएँ

बिना Android Studio के APK (GitHub से):
1) github.com पर फ्री अकाउंट -> New repository -> इस फोल्डर की सारी फाइलें (".github" फोल्डर समेत) अपलोड करें
2) Actions टैब -> "Build APK" चलने दें (5-8 मिनट) -> Artifacts में PhoneHealth-APK डाउनलोड करें
3) ZIP से app-debug.apk निकालकर फोन में इंस्टॉल करें (Unknown sources की अनुमति दें)
