package com.example.phonehealth

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.*
import android.os.*
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val PINK = Color.parseColor("#FF7EB6")
    private val MUTE = Color.parseColor("#A39099")
    private lateinit var tvTime: TextView; private lateinit var tvDate: TextView
    private lateinit var tvPct: TextView; private lateinit var tvNext: TextView
    private lateinit var tvStat: TextView; private lateinit var tvTl: TextView
    private lateinit var tvProb: TextView; private lateinit var tvNet: TextView
    private lateinit var tvPerm: TextView
    private var lastLevel = -1; private var lastChange = System.currentTimeMillis()

    private fun tv(sz: Float, col: Int = Color.WHITE, center: Boolean = false) = TextView(this).apply {
        textSize = sz; setTextColor(col); setPadding(0, 8, 0, 8); if (center) gravity = Gravity.CENTER
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 60); setBackgroundColor(Color.BLACK) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(root) })
        tvTime = tv(48f, center = true); tvDate = tv(16f, MUTE, true); tvPct = tv(72f, PINK, true); tvNext = tv(14f, MUTE, true)
        tvStat = tv(16f); tvTl = tv(15f); tvProb = tv(15f); tvNet = tv(15f); tvPerm = tv(15f)
        root.addView(tvTime); root.addView(tvDate); root.addView(tvPct); root.addView(tvNext)
        fun head(t: String) = root.addView(tv(18f, PINK).apply { text = t; setPadding(0, 36, 0, 8) })
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
        head("⚡ बैटरी"); root.addView(tvStat)
        head("🕒 आगे क्या होगा"); root.addView(tvTl)
        head("⚠️ खराबी"); root.addView(tvProb)
        head("📶 नेट / 5G"); root.addView(tvNet)
        head("🔐 अनुमति"); root.addView(tvPerm)
        head("बटन")
        btn("✅ सभी अनुमति दें") { askAll() }
        btn("🔔 रिंगटोन टेस्ट") { svc("TEST") }
        btn("⏹ रिंगटोन बंद") { svc("STOP") }
        btn("🔋 बैटरी ऑप्टिमाइज़ेशन बंद करें (बैकग्राउंड के लिए)") { ignoreBattery() }
        btn("📶 मोबाइल नेटवर्क / 5G सेटिंग") { open(Settings.ACTION_DATA_ROAMING_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS) }
        btn("💬 WhatsApp पर बैटरी स्टेटस भेजें") { whatsapp() }
        btn("⚙️ ऐप सेटिंग") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        try { startForegroundService(Intent(this, MonitorService::class.java)) } catch (e: Exception) { toast("सर्विस शुरू नहीं हुई: ${e.message}") }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    private val tick = object : Runnable { override fun run() { try { update() } catch (e: Exception) { tvProb.text = "एरर: ${e.message}" }; h.postDelayed(this, 200) } }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun svc(a: String) = try { startForegroundService(Intent(this, MonitorService::class.java).setAction(a)) } catch (e: Exception) { toast("एरर: ${e.message}") }
    private fun open(vararg actions: String) {
        for (a in actions) try { startActivity(Intent(a)); return } catch (e: Exception) {}
        toast("सेटिंग नहीं खुली — Settings → SIM/Mobile network → Preferred network type → 5G खुद चुनें")
    }

    private fun askAll() {
        val need = mutableListOf(Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val miss = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isEmpty()) { toast("सभी अनुमति पहले से मिली हैं"); ignoreBattery() } else requestPermissions(miss.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { toast(if (r.all { it == 0 }) "अनुमति मिल गई ✅" else "कुछ अनुमति मना हुई — ⚙️ ऐप सेटिंग से दें"); ignoreBattery() }
    private fun ignoreBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (e: Exception) { toast("एरर: ${e.message}") }
    }

    private var shareText = ""
    private fun whatsapp() {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, shareText) }
        try { startActivity(Intent(i).setPackage("com.whatsapp")) }
        catch (e: Exception) { try { startActivity(Intent(i).setPackage("com.whatsapp.w4b")) } catch (e2: Exception) { startActivity(Intent.createChooser(i, "भेजें")) } }
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun update() {
        val now = Date()
        tvTime.text = SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(now)
        tvDate.text = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(now)
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val vRaw = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val volt = if (vRaw > 100) vRaw / 1000f else vRaw.toFloat()
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val health = i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val raw = abs(bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
        val mA = if (raw > 20000) raw / 1000.0 else raw.toDouble()
        val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) / 1000.0
        val cap = if (counter > 0 && level > 0) counter / (level / 100.0) else 0.0
        var rate = if (cap > 0 && mA > 0) mA / cap * 100 / 3600 else 0.0  // % प्रति सेकंड
        if (rate <= 0) rate = 1.0 / 90

        if (level != lastLevel) { lastLevel = level; lastChange = System.currentTimeMillis() }
        val frac = minOf(0.99, (System.currentTimeMillis() - lastChange) / 1000.0 * rate)
        val disp = if (level >= 100) 100.0 else if (charging) level + frac else level + 0.99 - frac
        tvPct.text = String.format(Locale.US, "%.2f%%", disp)
        val left = Math.ceil((1 - frac) / rate).toInt()
        tvNext.text = (if (charging) "⚡ CHARGING   अगला +1% : " else "अगला −1% : ") + left + " सेकंड"

        val healthTxt = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "अच्छी ✅"; BatteryManager.BATTERY_HEALTH_OVERHEAT -> "ज़्यादा गर्म 🔥"
            BatteryManager.BATTERY_HEALTH_DEAD -> "खराब ❌"; BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "ओवर वोल्टेज ⚠️"
            BatteryManager.BATTERY_HEALTH_COLD -> "बहुत ठंडी ❄️"; else -> "अज्ञात" }
        val tLbl = if (temp >= 42) "🔥 Very Hot" else if (temp >= 37) "🔥 Hot" else if (temp >= 30) "🌡️ Warm" else "❄️ Cool"
        val src = when { plugged and 4 != 0 -> "वायरलेस"; plugged and 2 != 0 -> "USB"; plugged and 1 != 0 -> "AC चार्जर"; else -> "नहीं लगा" }
        tvStat.text = "वोल्टेज: %.3f V\nकरंट: %.0f mA\nपावर: %.1f W\nतापमान: %.1f°C  %s\nबैटरी हेल्थ: %s\nचार्जर: %s\nक्षमता (अनुमान): %.0f mAh".format(volt, mA, volt * mA / 1000, temp, tLbl, healthTxt, src, cap)

        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        tvStat.append("\nRAM खाली: %d / %d MB\nस्टोरेज खाली: %.1f / %.1f GB".format(mi.availMem / 1048576, mi.totalMem / 1048576, sf.availableBytes / 1e9, sf.totalBytes / 1e9))

        val t = StringBuilder(); val nowMs = System.currentTimeMillis(); val f = SimpleDateFormat("h:mm a", Locale.getDefault())
        val goals = if (charging) listOf(80, 100) else listOf(20, 10)
        for (g in goals) if ((charging && level < g) || (!charging && level > g)) {
            val sec = abs(g - disp) / rate
            t.append("$g% होगा: ${f.format(Date(nowMs + (sec * 1000).toLong()))} (${(sec / 60).toInt()} मिनट)\n")
        }
        tvTl.text = if (t.isEmpty()) "बैटरी फुल ✅" else t.toString().trim()

        val p = ArrayList<String>()
        if (temp >= 42) p.add("🔥 बैटरी बहुत गर्म — चार्जिंग रोकें, कवर हटाएँ")
        if (health != BatteryManager.BATTERY_HEALTH_GOOD && health != 0 && health != BatteryManager.BATTERY_HEALTH_UNKNOWN) p.add("🔋 बैटरी हेल्थ ठीक नहीं: $healthTxt")
        if (level <= 15 && !charging) p.add("🪫 बैटरी बहुत कम")
        if (plugged > 0 && !charging && level < 100) p.add("🔌 चार्जर लगा है पर चार्ज नहीं हो रहा — केबल/चार्जर बदलें")
        if (charging && level < 95 && mA in 1.0..500.0) p.add("🐢 चार्जिंग बहुत धीमी (${mA.toInt()} mA)")
        if (mi.availMem < mi.totalMem * 0.1) p.add("🧠 RAM लगभग भरी है — ऐप्स बंद करें")
        if (sf.availableBytes < sf.totalBytes * 0.05) p.add("💾 स्टोरेज लगभग भरा है")
        if (volt in 0.1..3.3) p.add("⚠️ वोल्टेज बहुत कम")
        tvProb.text = if (p.isEmpty()) "कोई समस्या नहीं ✅" else p.joinToString("\n")

        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        var net = "ऑफ़लाइन ❌"
        if (caps != null) {
            net = if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) "Wi-Fi" else if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                var gen = "(अनुमति दें)"
                if (granted(Manifest.permission.READ_PHONE_STATE)) try {
                    val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                    gen = when (tm.dataNetworkType) { 20 -> "5G ✅"; 13, 19 -> "4G (LTE)"; 3, 8, 9, 10, 15 -> "3G"; 1, 2 -> "2G"; else -> "अज्ञात" }
                } catch (e: SecurityException) {}
                "मोबाइल डेटा — $gen"
            } else "ऑनलाइन"
            net += "\nडाउनलोड स्पीड (अनुमान): ${caps.linkDownstreamBandwidthKbps / 1000} Mbps"
        }
        tvNet.text = net + "\n\n5G न दिखे तो: Preferred network type → 5G/4G/3G/2G (auto) चुनें; SIM/प्लान 5G वाला हो (कंपनी के ऐप/कस्टमर केयर से जाँचें)।"

        val ps = granted(Manifest.permission.READ_PHONE_STATE)
        val pn = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)
        val pw = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        tvPerm.text = "फोन/नेटवर्क स्टेटस: ${if (ps) "✅" else "❌"}\nNotification: ${if (pn) "✅" else "❌"}\nबैकग्राउंड (बैटरी ऑप्टिमाइज़ेशन बंद): ${if (pw) "✅" else "❌"}"
        shareText = "🔋 बैटरी %.1f%% | %s | %.3f V | %.0f mA | %.1f°C | नेट: %s".format(disp, if (charging) "चार्जिंग ⚡" else "डिस्चार्ज", volt, mA, temp, net.lineSequence().first())
    }
}
