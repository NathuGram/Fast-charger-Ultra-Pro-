package com.example.phonehealth

import android.app.*
import android.content.*
import android.media.*
import android.os.*

class MonitorService : Service() {
    private var player: MediaPlayer? = null
    private var ringing = false
    private var dismissed = false
    private var registered = false

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) > 0
            val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val trigger = when {
                plugged && lvl >= 100 -> "🔋 बैटरी फुल 100% — चार्जर निकालें"
                temp >= 45f -> "🔥 फोन बहुत गर्म (%.1f°C) — चार्जर निकालें, कवर हटाएँ".format(temp)
                !plugged && lvl <= 10 -> "🪫 बैटरी सिर्फ $lvl% — चार्ज पर लगाएँ"
                else -> null
            }
            if (trigger == null) { dismissed = false; stopRing() } else if (!dismissed) startRing(trigger)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("mon", "Battery monitor", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("full", "Battery full", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "mon").setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Phone Health चालू है").setContentText("फुल चार्ज होने पर रिंगटोन बजेगी").setContentIntent(pi).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        if (!registered) { registerReceiver(rcv, IntentFilter(Intent.ACTION_BATTERY_CHANGED)); registered = true }
        when (intent?.action) {
            "STOP" -> { dismissed = true; stopRing() }
            "TEST" -> startRing("🔔 रिंगटोन टेस्ट")
        }
        return START_STICKY
    }

    private fun startRing(msg: String) {
        if (ringing) return
        ringing = true
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setDataSource(this@MonitorService, uri)
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                isLooping = true; prepare(); start()
            }
            @Suppress("DEPRECATION")
            (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 300), 0))
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(2, Notification.Builder(this, "full").setSmallIcon(android.R.drawable.ic_lock_idle_charging)
                .setContentTitle("Phone Health अलर्ट").setContentText(msg).build())
        } catch (e: Exception) { ringing = false }
    }

    private fun stopRing() {
        ringing = false
        try { player?.stop(); player?.release() } catch (e: Exception) {}
        player = null
        @Suppress("DEPRECATION")
        (getSystemService(VIBRATOR_SERVICE) as Vibrator).cancel()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(2)
    }

    override fun onDestroy() {
        if (registered) unregisterReceiver(rcv)
        stopRing(); super.onDestroy()
    }
}
